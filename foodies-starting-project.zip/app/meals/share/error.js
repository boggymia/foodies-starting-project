'use client';

const MealsError = props => {
  const gettedError = props.error;
  return (
    <main className='error'>
      <h1>Error occurred!</h1>
      <p>Failed to create meal.</p>
    </main>
  );
};
export default MealsError;
