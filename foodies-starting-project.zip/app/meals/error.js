'use client';

const MealsError = props => {
  const gettedError = props.error;
  return (
    <main className='error'>
      <h1>Error occurred!</h1>
      <p>Failed to fetch meal data. Please try again later.</p>
    </main>
  );
};
export default MealsError;
