'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

import classes from './nav-link.module.css';

const NavLink = props => {
  const path = usePathname();
  return (
    <Link
      href={props.href}
      className={`${classes.link} ${path.startsWith(props.href) ? classes.active : undefined}`}
    >
      {props.children}
    </Link>
  );
};

export default NavLink;
