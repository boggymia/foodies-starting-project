'use client';

import { useState, useRef } from 'react';
import classes from './image-picker.module.css';
import Image from 'next/image';

const ImagePicker = props => {
  const [pickedImage, setPickedImage] = useState();
  const imageInputRef = useRef(props.name);

  const pickClickHandler = () => {
    return imageInputRef.current.click();
  };

  const imageChangeHandler = event => {
    const file = event.target.files[0];
    if (!file) {
      setPickedImage(null);
      return;
    }

    const fileReader = new FileReader();

    // this function calls when `readAsDataURL(file)` runs
    fileReader.onload = () => {
      setPickedImage(fileReader.result);
    };

    fileReader.readAsDataURL(file);
  };

  return (
    <div className={classes.picker}>
      <label htmlFor={props.name}>{props.label}</label>
      <div className={classes.controls}>
        <div className={classes.preview}>
          {!pickedImage && <p>No image picked yet.</p>}
          {pickedImage && (
            <Image src={pickedImage} alt='The image selected by the user.' fill />
          )}
        </div>
        <input
          className={classes.input}
          type='file'
          id={props.name}
          name={props.name}
          accept='image/png, image/jpeg'
          ref={imageInputRef}
          onChange={imageChangeHandler}
          required
        />
        <button className={classes.button} type='button' onClick={pickClickHandler}>
          Pick an Image
        </button>
      </div>
    </div>
  );
};

export default ImagePicker;
